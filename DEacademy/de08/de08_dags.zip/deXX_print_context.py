from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.utils.dates import days_ago
from pprint import pprint


# method to print out airflow dag context
def print_context(**kwargs):
    pprint(kwargs) # 透過pprint來讓輸出易讀


default_args = {
    'owner':'EMPLOYEE_ID', # owner是DAG的開發者, 例如: 員工8703147
}

dag = DAG(
    dag_id="deXX_print_context", # prefix必需是tenant id, 例如: de00
    description="dag to print out airflow dag context",
    start_date=days_ago(2),
    schedule_interval=None,
    catchup=False,
    default_args=default_args,
    access_control={
        'deXX': {'can_read', 'can_edit'} # 設定DAG歸屬那個團隊[tenant id]與權限
    },
    tags=['de08'],
)

# task to print out airflow dag context
task_print_context = PythonOperator(
    task_id='print_context',
    python_callable=print_context,
    dag=dag,
)

