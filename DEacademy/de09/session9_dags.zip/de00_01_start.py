from airflow import DAG
from airflow.utils.dates import days_ago
from airflow.operators.dummy import DummyOperator

default_args = {
    'owner':'8703147', # owner是DAG的開發者, 例如: 員工8703147
}

with DAG(
    dag_id="de00_01_start",  # prefix必需是tenant id, 例如: de00
    start_date=days_ago(2),
    schedule_interval=None,
    default_args=default_args,
    access_control={
        'de00': {'can_read', 'can_edit'}  # 設定DAG歸屬那個團隊[tenant id]與權限
    },
    tags=['de09'],
) as dag:
    start = DummyOperator(task_id="start")
    fetch_sales = DummyOperator(task_id="fetch_sales")
    clean_sales = DummyOperator(task_id="clean_sales")
    fetch_weather = DummyOperator(task_id="fetch_weather")
    clean_weather = DummyOperator(task_id="clean_weather")
    join_datasets = DummyOperator(task_id="join_datasets")
    train_model = DummyOperator(task_id="train_model")
    deploy_model = DummyOperator(task_id="deploy_model")

    start >> [fetch_sales, fetch_weather]
    fetch_sales >> clean_sales
    fetch_weather >> clean_weather
    [clean_sales, clean_weather] >> join_datasets
    join_datasets >> train_model >> deploy_model




